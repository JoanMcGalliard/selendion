package org.concordion.internal;

import org.concordion.api.Result;
import org.concordion.api.ResultRecorder;
import org.concordion.api.ResultSummary;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class SummarizingResultRecorder implements ResultRecorder, ResultSummary {

    private List<Result> recordedResults = new ArrayList<Result>();


    public void record(Result result) {
        recordedResults.add(result);
    }

    public void assertIsSatisfied(boolean isExpectedToPass) {
        if (hasFailures() && isExpectedToPass) {
            throw new AssertionError("Specification has failure(s). See output HTML for details.");
        }
        if (hasExceptions() && isExpectedToPass) {
            throw new AssertionError("Specification has exception(s). See output HTML for details.");
        }
        if (!isExpectedToPass && !hasExceptions() && !hasFailures()) {
            throw new AssertionError("Test has no failures or exceptions but is not expected to pass.");
        }
    }

    public boolean hasExceptions() {
        return getExceptionCount() > 0;
    }

    public boolean hasFailures() {
        return getFailureCount() > 0;
    }

    public long getCount(Result result) {
        int count = 0;
        for (Result candidate : recordedResults) {
            if (candidate == result) {
                count++;
            }
        }
        return count;
    }

    public long getExceptionCount() {
        return getCount(Result.EXCEPTION);
    }

    public long getFailureCount() {
        return getCount(Result.FAILURE);
    }

    public long getSuccessCount() {
        return getCount(Result.SUCCESS);
    }

    public void print(PrintStream out) {
        out.print("Successes: " + getSuccessCount());
        out.print(", Failures: " + getFailureCount());
        if (hasExceptions()) {
            out.print(", Exceptions: " + getExceptionCount());
        }
        out.println("\n");
    }

}
