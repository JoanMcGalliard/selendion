package org.concordion.api;

public interface SpecificationLocator {

    Resource locateSpecification(Object fixture);
}
